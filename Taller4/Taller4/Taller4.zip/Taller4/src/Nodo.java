public class Nodo {
    private Nodo next;
    private Nodo prev;
    private Pokemon dato;

    public Nodo(Pokemon dato) {
        this.next = null;
        this.prev = null;
        this.dato = dato;
    }

    public Nodo getNext() {
        return next;
    }

    public void setNext(Nodo next) {
        this.next = next;
    }

    public Nodo getPrev() {
        return prev;
    }

    public void setPrev(Nodo prev) {
        this.prev = prev;
    }

    public Pokemon getDato() {
        return dato;
    }

    public void setDato(Pokemon dato) {
        this.dato = dato;
    }
}
