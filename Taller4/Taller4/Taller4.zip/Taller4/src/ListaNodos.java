import ucn.StdOut;

public class ListaNodos {
    private Nodo head;
    private Nodo tail;
    private int cantActual;

    public ListaNodos() {
        this.head = null;
        this.tail = null;
        this.cantActual = 0;
    }

    public Nodo getContiene(int id) {
        Nodo aux = head;

        while (aux != null) {
            if (aux.getDato().getId() == id) {
                return aux;
            }
            aux = aux.getNext();
        }

        return null;
    }

    public Nodo getContiene(String nombre) {
        Nodo aux = head;

        while (aux != null) {
            if (aux.getDato().getNombrePokemon().equalsIgnoreCase(nombre)) {
                return aux;
            }
            aux = aux.getNext();
        }

        return null;
    }

    public void mostrarLista (){
        Nodo nodo = this.tail;
        while (nodo.getNext() != this.tail ){
            StdOut.println(nodo.getDato().getId());
            StdOut.println(nodo.getDato().getNombrePokemon().trim());
            StdOut.println(nodo.getDato().getEtapa().trim());
            if (!nodo.getDato().getEvolucionPrevia().equalsIgnoreCase("")){
                StdOut.println(nodo.getDato().getEvolucionPrevia().trim());
            }

            if (!nodo.getDato().getEvolucionSiguiente().equals("")){
                StdOut.println(nodo.getDato().getEvolucionSiguiente().trim());
            }

            StdOut.println(nodo.getDato().getTipo1().trim());

            if (nodo.getDato().getTipo2() != null){
                StdOut.println(nodo.getDato().getTipo2().trim());
            }
            StdOut.println();

            nodo = nodo.getNext();
        }
        StdOut.println(nodo.getDato().getId());
        StdOut.println(nodo.getDato().getNombrePokemon().trim());
        StdOut.println(nodo.getDato().getEtapa().trim());
        if (!nodo.getDato().getEvolucionPrevia().equalsIgnoreCase("")){
            StdOut.println(nodo.getDato().getEvolucionPrevia().trim());
        }

        if (!nodo.getDato().getEvolucionSiguiente().equals("")){
            StdOut.println(nodo.getDato().getEvolucionSiguiente().trim());
        }

        StdOut.println(nodo.getDato().getTipo1().trim());

        if (nodo.getDato().getTipo2() != null){
            StdOut.println(nodo.getDato().getTipo2().trim());
        }

    }

    public void agregarNodoFinal(Pokemon pokemon){
        Nodo nodo = new Nodo(pokemon);

        if (this.head == null && this.tail == null){
            this.head = nodo;
            nodo.setNext(nodo);
            this.tail = nodo;
            nodo.setPrev(nodo);
            this.cantActual++;
            return;
        }

        nodo.setPrev(this.head);
        nodo.setNext(this.tail);
        this.head.setNext(nodo);
        this.head=nodo;
        this.cantActual++;

    }
    public Nodo getHead() {
        return head;
    }

    public void setHead(Nodo head) {
        this.head = head;
    }

    public Nodo getTail() {
        return tail;
    }

    public void setTail(Nodo tail) {
        this.tail = tail;
    }

    public int getCantActual() {
        return cantActual;
    }

    public void setCantActual(int cantActual) {
        this.cantActual = cantActual;
    }
}
