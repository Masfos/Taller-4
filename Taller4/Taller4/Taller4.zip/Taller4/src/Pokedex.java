import java.io.IOException;

public interface Pokedex {
    void leerArchivos() throws IOException;

    void cierreEpico();

    void buscarPorID(int id);


    void buscarPorNombre(String nombre);

    void orden();
}
